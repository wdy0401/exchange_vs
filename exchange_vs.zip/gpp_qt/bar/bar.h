#ifndef BAR
#define BAR

class bar
{
public:

private:
	
};

#endif

