#define BUILD_SAMPLE_TACTIC_DLL

#include"sample_tactic.h"
#include"../wtimer/wtimer.h"


extern wtimer tm;


void updateinfo(const orderlist & ol, const orderbook & ob)
{
	
}