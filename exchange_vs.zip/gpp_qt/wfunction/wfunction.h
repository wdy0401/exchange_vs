#ifndef WFUNCTION
#define WFUNCTION

#include<string>
#include<iostream> 
#include<stdlib.h>
#include<sstream>
#include<list>
#include<windows.h>
class wfunction
{
public:
	static std::string itos(long);
	static std::string ftos(double);
	static std::list<std::string> splitstring(std::string);
	static std::list<std::string> splitstring(std::string,std::string);
	static char * gbk2utf8(const char*);
	static char * utf82gbk(const char*);
};
#endif