#include"bar.h"
#include"../wtimer/wtimer.h"

extern wtimer tm;
