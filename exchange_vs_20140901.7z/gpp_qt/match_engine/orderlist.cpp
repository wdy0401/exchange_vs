#include"orderlist.h"

using namespace std;

orderlist::orderlist()
{
	_ordercount=0;
}